
document.addEventListener("DOMContentLoaded", () => {

  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const target = document.querySelector(link.getAttribute("href"));
      if (target) target.scrollIntoView({ behavior: "smooth" });
    });
  });

  
  const cta = document.querySelector(".cta");
  if (cta) {
    cta.addEventListener("click", () => {
      window.location.href = "catalog.html";
    });
  }


  const cards = document.querySelectorAll(".card");
  cards.forEach(card => {
    card.addEventListener("mouseover", () => {
      card.style.transform = "translateY(-6px)";
      card.style.transition = "0.3s ease";
      card.style.boxShadow = "0 6px 18px rgba(0,0,0,0.18)";
    });
    card.addEventListener("mouseout", () => {
      card.style.transform = "translateY(0)";
      card.style.boxShadow = "none";
    });
  });


  const header = document.querySelector(".site-header");
  let mobileBtn = document.querySelector(".mobile-menu-btn");

  if (!mobileBtn) {
    
    mobileBtn = document.createElement("div");
    mobileBtn.classList.add("mobile-menu-btn");
    mobileBtn.innerHTML = "&#9776;"; 
    header.appendChild(mobileBtn);
  }

  mobileBtn.addEventListener("click", () => {
    header.classList.toggle("menu-open");
  });

 
  console.log("%cFsaNews Book carregado com sucesso!", "color: #42a5f5; font-size: 14px;");
});

document.addEventListener("DOMContentLoaded", () => {

  const form = document.querySelector(".form");
  if (form) {
    
    form.addEventListener("submit", (e) => {
      e.preventDefault(); // Evita recarregar a página

      const nome = form.querySelector('input[type="text"]');
      const email = form.querySelector('input[type="email"]');
      const msg = form.querySelector("textarea");

      
      if (!nome.value.trim() || !email.value.trim() || !msg.value.trim()) {
        alert("Por favor, preencha todos os campos.");
        return;
      }

      
      const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!regexEmail.test(email.value)) {
        alert("Digite um e-mail válido.");
        return;
      }

      
      form.querySelector("button").innerText = "Enviando...";
      form.querySelector("button").disabled = true;

      setTimeout(() => {
        
        const dados = {
          nome: nome.value,
          email: email.value,
          mensagem: msg.value,
          data: new Date().toLocaleString("pt-BR"),
        };

        localStorage.setItem("ultimaMensagemContato", JSON.stringify(dados));

       
        alert("Mensagem enviada com sucesso! Obrigado pelo contato.");

        form.reset();
        form.querySelector("button").innerText = "Enviar";
        form.querySelector("button").disabled = false;

      }, 1200);

    });
  }
});


const USERS = {
  "admin": { password: "1234", type: "Administrador" },
  "usuario": { password: "1234", type: "Usuário" }
};


function getCurrentPage() {
  const p = window.location.pathname.split("/").pop();
  return p === "" ? "index.html" : p;
}


document.addEventListener("DOMContentLoaded", () => {

  const currentPage = getCurrentPage();
  document.querySelectorAll("header nav ul li a").forEach(link => {
    if (link.getAttribute("href") === currentPage) {
      link.classList.add("active");
    }
  });
  setupHeaderUser();

  // 3) Login: se estiver na página login, configurar o formulário
  const loginForm = document.getElementById("loginForm");
  if (loginForm) setupLoginForm(loginForm);

  const contactForm = document.querySelector(".form");
  if (contactForm && window.location.pathname.includes("contact.html")) {
    setupContactForm(contactForm);
  }

  // 5) Animar cards quando aparecem (catalog / audiobook)
  setupCardObserver();

 
  setupCatalogModal();

  const verMensagens = document.getElementById("verMensagens");
  if (verMensagens) {
    verMensagens.addEventListener("click", (e) => {
      e.preventDefault();
      showSavedMessages();
    });
  }

  console.log("FsaNews Book — scripts carregados.");
});


function setupHeaderUser() {
  const headerNav = document.querySelector(".site-header nav ul");
  if (!headerNav) return;

  // Remove itens anteriores adicionados (evita duplicação em hot reload)
  const prev = headerNav.querySelectorAll(".user-info-injected");
  prev.forEach(n => n.remove());

  const loggedUser = localStorage.getItem("loggedUser");
  const userType = localStorage.getItem("userType");

  if (loggedUser) {
    // item exibindo tipo
    const liInfo = document.createElement("li");
    liInfo.className = "user-info-injected";
    liInfo.innerHTML = `<span style="font-weight:bold;color:#0b6;">${userType}</span>`;
    headerNav.appendChild(liInfo);

    // logout
    const liLogout = document.createElement("li");
    liLogout.className = "user-info-injected";
    liLogout.innerHTML = `<a href="#" id="logoutBtn" style="color:#d33;font-weight:bold;">Sair</a>`;
    headerNav.appendChild(liLogout);

    // evento
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", (e) => {
        e.preventDefault();
        localStorage.removeItem("loggedUser");
        localStorage.removeItem("userType");
        // Atualiza header e redireciona para login
        setupHeaderUser();
        window.location.href = "login.html";
      });
    }
  }
}


function setupLoginForm(form) {
  const message = document.getElementById("loginMessage");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const user = document.getElementById("username").value.trim();
    const pass = document.getElementById("password").value.trim();

    if (!user || !pass) {
      message.style.color = "red";
      message.textContent = "Preencha usuário e senha.";
      return;
    }

    if (USERS[user] && USERS[user].password === pass) {
      const uType = USERS[user].type;
      localStorage.setItem("loggedUser", user);
      localStorage.setItem("userType", uType);

      message.style.color = "green";
      message.textContent = `Login bem-sucedido! Bem-vindo, ${uType}.`;

      
      setupHeaderUser();

      setTimeout(() => {
        if (uType === "Administrador") {
          window.location.href = "admin.html";
        } else {
          window.location.href = "index.html";
        }
      }, 900);

    } else {
      message.style.color = "red";
      message.textContent = "Usuário ou senha incorretos.";
    }
  });
}


function setupContactForm(form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const nome = form.querySelector('input[type="text"]');
    const email = form.querySelector('input[type="email"]');
    const msg = form.querySelector("textarea");

    if (!nome.value.trim() || !email.value.trim() || !msg.value.trim()) {
      alert("Por favor, preencha todos os campos.");
      return;
    }

    const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regexEmail.test(email.value)) {
      alert("Digite um e-mail válido.");
      return;
    }

    
    const nova = {
      nome: nome.value.trim(),
      email: email.value.trim(),
      mensagem: msg.value.trim(),
      data: new Date().toLocaleString("pt-BR")
    };

  
    const arr = JSON.parse(localStorage.getItem("mensagensContato") || "[]");
    arr.push(nova);
    localStorage.setItem("mensagensContato", JSON.stringify(arr));

    alert("Mensagem enviada com sucesso! Obrigado pelo contato.");
    form.reset();
  });
}


function setupCardObserver() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("show");
      }
    });
  }, { threshold: 0.18 });

  document.querySelectorAll(".card").forEach(card => {
    observer.observe(card);
  });
}


   
function setupCatalogModal() {
  const comprarBtns = document.querySelectorAll(".card .btn");

  if (comprarBtns.length === 0) return;

  
  let modal = document.createElement("div");
  modal.className = "modal-compra";
  modal.style.cssText = `
    position: fixed; left: 0; top: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.55);
    display: none; justify-content: center; align-items: center;
    z-index: 9999; backdrop-filter: blur(4px);
  `;
  modal.innerHTML = `
    <div style="background:#fff;padding:22px;width:90%;max-width:420px;border-radius:10px;text-align:center;animation: fadeIn .24s ease;">
      <h2 id="modalTitulo">Livro selecionado</h2>
      <p id="modalDescricao" style="color:#333;margin:12px 0 18px"></p>
      <button id="fecharModal" class="btn" style="width:100%">Fechar</button>
    </div>
  `;
  document.body.appendChild(modal);

  const modalTitulo = modal.querySelector("#modalTitulo");
  const modalDescricao = modal.querySelector("#modalDescricao");
  const fecharModal = modal.querySelector("#fecharModal");

  comprarBtns.forEach(btn => {
    btn.addEventListener("click", (e) => {
      
      if (btn.getAttribute("href") === "#" || btn.getAttribute("href") === null) {
        e.preventDefault();
      }
      const card = btn.closest(".card");
      const titulo = card.querySelector("h3") ? card.querySelector("h3").innerText : "Item";
      const descricao = card.querySelector("p") ? card.querySelector("p").innerText : "";

      modalTitulo.innerText = titulo;
      modalDescricao.innerText = descricao;

      localStorage.setItem("livroSelecionado", JSON.stringify({
        titulo, descricao, data: new Date().toLocaleString("pt-BR")
      }));

      modal.style.display = "flex";
    });
  });

  fecharModal.addEventListener("click", () => {
    modal.style.display = "none";
  });

  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });
}


function showSavedMessages() {
  const cont = document.getElementById("mensagensContainer");
  const lista = document.getElementById("listaMensagens");
  if (!cont || !lista) return;

  const arr = JSON.parse(localStorage.getItem("mensagensContato") || "[]");
  if (arr.length === 0) {
    lista.innerHTML = "<p>Nenhuma mensagem salva.</p>";
  } else {
    lista.innerHTML = arr.map(m => {
      return `<div style="border:1px solid #eee;padding:10px;border-radius:6px;margin-bottom:8px">
                <strong>${escapeHtml(m.nome)}</strong> — <em>${m.data}</em><br>
                <small>${escapeHtml(m.email)}</small>
                <p style="margin-top:8px">${escapeHtml(m.mensagem)}</p>
              </div>`;
    }).join("");
  }

  cont.style.display = "block";
}


function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


